package com.aigreentick.services.template.api.dto.request.create;

import java.util.List;

import com.aigreentick.services.template.domain.enums.CardComponentFormat;
import com.aigreentick.services.template.domain.enums.CardComponentType;

import lombok.Data;

@Data
public class WhatsappTemplateCarouseCardComponentRequestDto {
    private CardComponentType type;

    private CardComponentFormat format;

    private String text;

    private WhatsappTemplateExampleRequestDto example;

    private List<WhatsappTemplateCarouselButtonRequestDto> buttons;
}
