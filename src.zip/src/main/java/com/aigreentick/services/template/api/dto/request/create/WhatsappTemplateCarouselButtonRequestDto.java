package com.aigreentick.services.template.api.dto.request.create;

import java.util.List;

import com.aigreentick.services.template.domain.enums.ButtonType;

import lombok.Data;

@Data
public class WhatsappTemplateCarouselButtonRequestDto {
    private ButtonType type; 

    private String text;

    private Integer index;

    private String url;

    private List<String> example; 
    
    private String phoneNumber;

}
