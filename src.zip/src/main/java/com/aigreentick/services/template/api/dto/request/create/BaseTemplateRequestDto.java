package com.aigreentick.services.template.api.dto.request.create;

import java.util.List;

import com.aigreentick.services.template.domain.enums.TemplateCategory;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class BaseTemplateRequestDto {

    @NotNull(message = "tempalte name cannot be null")
    private String name;
     
    private String language;

    private TemplateCategory category;

    private List<WhatsappTemplateComponentRequestDto> components;


}
