package com.aigreentick.services.template.api.dto.request.create;

import java.util.List;

import lombok.Data;

@Data
public class CreateTemplateRequestDto {
    private BaseTemplateRequestDto template;

    private List<WhatsappTemplateVariablesRequestDto> variables;

    // private List<MediaUrlMappingRequestDto> mediaUrls;

    private String wabaId;

    private boolean isDraft = false;

}
