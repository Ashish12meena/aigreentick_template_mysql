package com.aigreentick.services.template.application.port;

import com.aigreentick.services.template.api.dto.response.client.AccessTokenIdentifier;
import com.aigreentick.services.template.api.dto.response.client.WhatsappAccountCredentials;

/**
 * Port for resolving WhatsApp Business Account credentials.
 * Application layer depends on this interface — never on the HTTP adapter directly.
 */
public interface WabaCredentialPort {

    /**
     * Resolves only the access token for a given WABA ID.
     * Used by create, submit, delete, sync flows.
     */
    AccessTokenIdentifier getWhatsappAccountWabaAccessToken(String wabaId);

    /**
     * Resolves full credentials for a given WABA ID.
     * Used by media upload flow.
     */
    WhatsappAccountCredentials getWhatsappAccountAppAccessToken(String wabaId);
}