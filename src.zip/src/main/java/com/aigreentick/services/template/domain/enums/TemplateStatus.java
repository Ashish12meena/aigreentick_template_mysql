package com.aigreentick.services.template.domain.enums;

public enum TemplateStatus {
    DRAFT,
    NEW_CREATED,
    SUBMITTED,
    PENDING,
    APPROVED,
    REJECTED,
    PAUSED,
    DISABLED,
    FAILED,
}
