package com.aigreentick.services.template.api.dto.request.create;

import java.util.List;

import com.aigreentick.services.template.domain.enums.ButtonType;
import com.aigreentick.services.template.domain.enums.OtpType;

import lombok.Data;

@Data
public class WhatsappTemplateButtonRequestDto {

    private ButtonType type;

    private OtpType otpType;

    private String phoneNumber;

    private String text;

    private Integer index;

    private String url;

    private String autofillText;

    List<String> example;

    List<WhatsappTemplateButtonSupportedAppRequestDto> supportedApps;
}
