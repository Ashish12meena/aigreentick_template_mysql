package com.aigreentick.services.template.api.dto.request.create;

import java.util.List;

import com.aigreentick.services.template.domain.enums.ComponentType;

import lombok.Data;

@Data
public class WhatsappTemplateComponentRequestDto {

    private ComponentType type;

    private String format;
    
    private String text;


    private Boolean addSecurityRecommendation;

    private Integer codeExpirationMinutes;

    private List<WhatsappTemplateButtonRequestDto> buttons;

    private List<WhatsappTemplateCarouselCardRequestDto> cards;

    private WhatsappTemplateExampleRequestDto example;
}
