package com.aigreentick.services.template.api.dto.request.create;

import com.aigreentick.services.template.domain.enums.VariableComponentType;

import lombok.Data;

@Data
public class WhatsappTemplateVariablesRequestDto {

    private VariableComponentType componentType;

    private Integer variableIndex;

    private String label;

    private String labelValue;
    
    private Integer buttonIndex = -1;

    private Integer cardIndex = -1;

}
