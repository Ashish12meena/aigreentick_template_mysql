package com.aigreentick.services.template.application.usecase;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aigreentick.services.template.api.dto.request.create.BaseTemplateRequestDto;
import com.aigreentick.services.template.api.dto.request.create.CreateTemplateRequestDto;
import com.aigreentick.services.template.api.dto.response.TemplateResponseDto;
import com.aigreentick.services.template.application.mapper.WhatsappTemplateMapper;
import com.aigreentick.services.template.application.service.MetaTemplateSubmissionService;
import com.aigreentick.services.template.common.util.helper.JsonHelper;
import com.aigreentick.services.template.domain.model.WhatsappTemplate;
import com.aigreentick.services.template.domain.service.TemplateCommandService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class CreateTemplateUseCase {

    private final TemplateCommandService commandService;
    private final WhatsappTemplateMapper templateMapper;
    private final MetaTemplateSubmissionService metaSubmission;

    /**
     * Creates a WhatsApp template.
     *
     * Flow:
     *   1. Validate no duplicate exists (ignores DRAFTs)
     *   2. Build and save as DRAFT
     *   3. If isDraft=true → return immediately
     *   4. If isDraft=false → submit to Meta
     */
    @Transactional
    public TemplateResponseDto execute(CreateTemplateRequestDto request,
            Long projectId, Long organizationId) {

        BaseTemplateRequestDto templateReq = request.getTemplate();

        // Step 1: Duplicate check
        commandService.ensureNoDuplicate(
                templateReq.getName(), templateReq.getLanguage(),
                projectId, request.getWabaId());

        // Step 2: Build and save as DRAFT
        String payload = JsonHelper.serializeWithSnakeCase(templateReq);
        WhatsappTemplate template = templateMapper.mapToTemplateEntity(
                payload, projectId, organizationId, request);
        template = commandService.save(template);

        log.info("Template saved as DRAFT id={} project={} components={} variables={}",
                template.getId(), projectId,
                template.getComponents() != null ? template.getComponents().size() : 0,
                template.getVariables() != null ? template.getVariables().size() : 0);

        // Step 3: Draft-only? Return early
        if (request.isDraft()) {
            return templateMapper.mapToTemplateResponse(template);
        }

        // Step 4: Submit to Meta
        return metaSubmission.submitToMeta(template, payload, request.getWabaId());
    }
}