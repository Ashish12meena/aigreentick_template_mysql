package com.aigreentick.services.template.application.usecase;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.aigreentick.services.template.api.dto.response.TemplateResponseDto;
import com.aigreentick.services.template.application.service.MetaTemplateSubmissionService;
import com.aigreentick.services.template.common.exception.InvalidTemplateStateException;
import com.aigreentick.services.template.domain.enums.TemplateStatus;
import com.aigreentick.services.template.domain.model.WhatsappTemplate;
import com.aigreentick.services.template.domain.service.TemplateQueryService;

@ExtendWith(MockitoExtension.class)
class SubmitDraftToMetaUseCaseTest {

    @Mock
    private TemplateQueryService queryService;

    @Mock
    private MetaTemplateSubmissionService metaSubmission;

    @InjectMocks
    private SubmitDraftToMetaUseCase submitDraftToMetaUseCase;

    @Test
    void execute_shouldSubmitDraftToMetaSuccessfully() {

        // Arrange
        WhatsappTemplate fakeDraft = new WhatsappTemplate();
        fakeDraft.setId(1L);
        fakeDraft.setName("order_confirmation");
        fakeDraft.setStatus(TemplateStatus.DRAFT);
        fakeDraft.setWabaId("waba-123");
        fakeDraft.setSubmissionPayload("{\"name\":\"order_confirmation\"}");

        TemplateResponseDto fakeResponse = TemplateResponseDto.builder()
                .id(1L)
                .name("order_confirmation")
                .status(TemplateStatus.PENDING)
                .metaTemplateId("meta-456")
                .build();

        when(queryService.getDraftByIdAndProject(1L, 1L)).thenReturn(fakeDraft);
        when(metaSubmission.submitToMeta(
                fakeDraft,
                "{\"name\":\"order_confirmation\"}",
                "waba-123"))
                .thenReturn(fakeResponse);

        // Act
        TemplateResponseDto result = submitDraftToMetaUseCase.execute(1L, 1L);

        // Assert
        assertThat(result).isNotNull();
        assertThat(result.getMetaTemplateId()).isEqualTo("meta-456");
        assertThat(result.getStatus()).isEqualTo(TemplateStatus.PENDING);

        verify(queryService).getDraftByIdAndProject(1L, 1L);
        verify(metaSubmission).submitToMeta(
                fakeDraft,
                "{\"name\":\"order_confirmation\"}",
                "waba-123");
    }

    @Test
    void execute_shouldThrowInvalidTemplateStateWhenTemplateIsNotDraft() {

        // Arrange
        // getDraftByIdAndProject throws when template is not DRAFT
        when(queryService.getDraftByIdAndProject(1L, 1L))
                .thenThrow(new InvalidTemplateStateException(
                        "Template id=1 is not in DRAFT status. Current status: APPROVED"));

        // Act + Assert
        assertThatThrownBy(() -> submitDraftToMetaUseCase.execute(1L, 1L))
                .isInstanceOf(InvalidTemplateStateException.class)
                .hasMessageContaining("APPROVED");
    }

    @Test
    void execute_shouldThrowInvalidTemplateStateWhenSubmissionPayloadIsNull() {

        // Arrange
        // Template is DRAFT but has no submission payload
        // This happens when draft was created but never had components set
        WhatsappTemplate fakeDraft = new WhatsappTemplate();
        fakeDraft.setId(1L);
        fakeDraft.setStatus(TemplateStatus.DRAFT);
        fakeDraft.setSubmissionPayload(null);   // no payload

        when(queryService.getDraftByIdAndProject(1L, 1L)).thenReturn(fakeDraft);

        // Act + Assert
        assertThatThrownBy(() -> submitDraftToMetaUseCase.execute(1L, 1L))
                .isInstanceOf(InvalidTemplateStateException.class)
                .hasMessageContaining("no submission payload");
    }

    @Test
    void execute_shouldThrowInvalidTemplateStateWhenSubmissionPayloadIsBlank() {

        // Arrange
        WhatsappTemplate fakeDraft = new WhatsappTemplate();
        fakeDraft.setId(1L);
        fakeDraft.setStatus(TemplateStatus.DRAFT);
        fakeDraft.setSubmissionPayload("   ");  // blank payload

        when(queryService.getDraftByIdAndProject(1L, 1L)).thenReturn(fakeDraft);

        // Act + Assert
        assertThatThrownBy(() -> submitDraftToMetaUseCase.execute(1L, 1L))
                .isInstanceOf(InvalidTemplateStateException.class)
                .hasMessageContaining("no submission payload");
    }
}