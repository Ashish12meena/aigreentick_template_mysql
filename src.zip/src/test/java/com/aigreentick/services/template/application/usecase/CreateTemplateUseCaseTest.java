package com.aigreentick.services.template.application.usecase;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.aigreentick.services.template.api.dto.request.create.BaseTemplateRequestDto;
import com.aigreentick.services.template.api.dto.request.create.CreateTemplateRequestDto;
import com.aigreentick.services.template.api.dto.response.TemplateResponseDto;
import com.aigreentick.services.template.application.mapper.WhatsappTemplateMapper;
import com.aigreentick.services.template.application.service.MetaTemplateSubmissionService;
import com.aigreentick.services.template.common.exception.DuplicateResourceException;
import com.aigreentick.services.template.domain.enums.TemplateCategory;
import com.aigreentick.services.template.domain.enums.TemplateStatus;
import com.aigreentick.services.template.domain.model.WhatsappTemplate;
import com.aigreentick.services.template.domain.service.TemplateCommandService;

@ExtendWith(MockitoExtension.class)
class CreateTemplateUseCaseTest {

    @Mock
    private TemplateCommandService commandService;

    @Mock
    private WhatsappTemplateMapper templateMapper;

    @Mock
    private MetaTemplateSubmissionService metaSubmission;

    @InjectMocks
    private CreateTemplateUseCase createTemplateUseCase;

    // ── helper to build a valid request ──────────────────────────────────────

    private CreateTemplateRequestDto buildRequest(boolean isDraft) {
        BaseTemplateRequestDto base = new BaseTemplateRequestDto();
        base.setName("order_confirmation");
        base.setLanguage("en");
        base.setCategory(TemplateCategory.UTILITY);

        CreateTemplateRequestDto request = new CreateTemplateRequestDto();
        request.setTemplate(base);
        request.setWabaId("waba-123");
        request.setDraft(isDraft);
        return request;
    }

    // ── isDraft = true ────────────────────────────────────────────────────────

    @Test
    void execute_shouldSaveAsDraftAndReturnWithoutSubmittingToMetaWhenIsDraftIsTrue() {

        // Arrange
        CreateTemplateRequestDto request = buildRequest(true);

        WhatsappTemplate savedTemplate = new WhatsappTemplate();
        savedTemplate.setId(1L);
        savedTemplate.setName("order_confirmation");
        savedTemplate.setStatus(TemplateStatus.DRAFT);

        TemplateResponseDto expectedResponse = TemplateResponseDto.builder()
                .id(1L)
                .name("order_confirmation")
                .status(TemplateStatus.DRAFT)
                .build();

        when(templateMapper.mapToTemplateEntity(anyString(), eq(1L), eq(2L), eq(request)))
                .thenReturn(savedTemplate);
        when(commandService.save(savedTemplate)).thenReturn(savedTemplate);
        when(templateMapper.mapToTemplateResponse(savedTemplate)).thenReturn(expectedResponse);

        // Act
        TemplateResponseDto result = createTemplateUseCase.execute(request, 1L, 2L);

        // Assert
        assertThat(result.getStatus()).isEqualTo(TemplateStatus.DRAFT);

        // Meta submission should NEVER be called for drafts
        verify(metaSubmission, never()).submitToMeta(any(), anyString(), anyString());
        verify(commandService).save(savedTemplate);
    }

    // ── isDraft = false ───────────────────────────────────────────────────────

    @Test
    void execute_shouldSubmitToMetaWhenIsDraftIsFalse() {

        // Arrange
        CreateTemplateRequestDto request = buildRequest(false);

        WhatsappTemplate savedTemplate = new WhatsappTemplate();
        savedTemplate.setId(1L);
        savedTemplate.setName("order_confirmation");
        savedTemplate.setStatus(TemplateStatus.DRAFT);

        TemplateResponseDto expectedResponse = TemplateResponseDto.builder()
                .id(1L)
                .name("order_confirmation")
                .status(TemplateStatus.PENDING)
                .metaTemplateId("meta-123")
                .build();

        when(templateMapper.mapToTemplateEntity(anyString(), eq(1L), eq(2L), eq(request)))
                .thenReturn(savedTemplate);
        when(commandService.save(savedTemplate)).thenReturn(savedTemplate);
        when(metaSubmission.submitToMeta(eq(savedTemplate), anyString(), eq("waba-123")))
                .thenReturn(expectedResponse);

        // Act
        TemplateResponseDto result = createTemplateUseCase.execute(request, 1L, 2L);

        // Assert
        assertThat(result.getMetaTemplateId()).isEqualTo("meta-123");
        assertThat(result.getStatus()).isEqualTo(TemplateStatus.PENDING);

        // Meta submission MUST be called when isDraft=false
        verify(metaSubmission).submitToMeta(eq(savedTemplate), anyString(), eq("waba-123"));
    }

    // ── duplicate check ───────────────────────────────────────────────────────

    @Test
    void execute_shouldThrowDuplicateResourceExceptionWhenTemplateAlreadyExists() {

        // Arrange
        CreateTemplateRequestDto request = buildRequest(false);

        // ensureNoDuplicate throws before any save happens
        // doThrow for void method
        org.mockito.Mockito.doThrow(new DuplicateResourceException(
                "Template with name 'order_confirmation' and language 'en' already exists"))
                .when(commandService).ensureNoDuplicate(
                        eq("order_confirmation"), eq("en"), eq(1L), eq("waba-123"));

        // Act + Assert
        assertThatThrownBy(() -> createTemplateUseCase.execute(request, 1L, 2L))
                .isInstanceOf(DuplicateResourceException.class)
                .hasMessageContaining("order_confirmation");

        // save should NEVER be called if duplicate check fails
        verify(commandService, never()).save(any());
        verify(metaSubmission, never()).submitToMeta(any(), anyString(), anyString());
    }
}