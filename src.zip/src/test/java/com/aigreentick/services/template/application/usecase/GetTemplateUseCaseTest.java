package com.aigreentick.services.template.application.usecase;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import com.aigreentick.services.template.api.dto.response.TemplateResponseDto;
import com.aigreentick.services.template.api.mapper.TemplateResponseMapper;
import com.aigreentick.services.template.common.exception.ResourceNotFoundException;
import com.aigreentick.services.template.domain.enums.TemplateStatus;
import com.aigreentick.services.template.domain.model.WhatsappTemplate;
import com.aigreentick.services.template.domain.service.TemplateQueryService;

// ── @ExtendWith(MockitoExtension.class) ───────────────────────────────────────
// Pure Mockito — no Spring context loaded at all
// Much faster than @WebMvcTest or @SpringBootTest
// @Mock creates fakes, @InjectMocks creates the real class with fakes injected
// ─────────────────────────────────────────────────────────────────────────────
@ExtendWith(MockitoExtension.class)
class GetTemplateUseCaseTest {

    @Mock
    private TemplateQueryService queryService;

    @Mock
    private TemplateResponseMapper responseMapper;

    @InjectMocks
    private GetTemplateUseCase getTemplateUseCase;

    // ── getById ───────────────────────────────────────────────────────────────

    @Test
    void getById_shouldReturnTemplateWhenFound() {

        // Arrange
        WhatsappTemplate fakeTemplate = new WhatsappTemplate();
        fakeTemplate.setId(1L);
        fakeTemplate.setName("order_confirmation");
        fakeTemplate.setStatus(TemplateStatus.APPROVED);

        when(queryService.getByIdAndProject(1L, 1L)).thenReturn(fakeTemplate);

        // Act
        WhatsappTemplate result = getTemplateUseCase.getById(1L, 1L);

        // Assert
        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo(1L);
        assertThat(result.getName()).isEqualTo("order_confirmation");
        assertThat(result.getStatus()).isEqualTo(TemplateStatus.APPROVED);

        verify(queryService).getByIdAndProject(1L, 1L);
    }

    @Test
    void getById_shouldThrowResourceNotFoundWhenTemplateDoesNotExist() {

        // Arrange
        // queryService throws — use case should propagate it
        when(queryService.getByIdAndProject(99L, 1L))
                .thenThrow(new ResourceNotFoundException("Template", "id", 99L));

        // Act + Assert
        // assertThatThrownBy — cleaner than try/catch in tests
        assertThatThrownBy(() -> getTemplateUseCase.getById(99L, 1L))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("99");
    }

    // ── getByNameAndLanguage ──────────────────────────────────────────────────

    @Test
    void getByNameAndLanguage_shouldReturnTemplateWhenFound() {

        // Arrange
        WhatsappTemplate fakeTemplate = new WhatsappTemplate();
        fakeTemplate.setId(1L);
        fakeTemplate.setName("promo");
        fakeTemplate.setLanguage("en");

        when(queryService.getByNameLanguageAndWaba(1L, "promo", "en", "waba-123"))
                .thenReturn(fakeTemplate);

        // Act
        WhatsappTemplate result = getTemplateUseCase
                .getByNameAndLanguage(1L, "promo", "en", "waba-123");

        // Assert
        assertThat(result.getName()).isEqualTo("promo");
        assertThat(result.getLanguage()).isEqualTo("en");
    }

    @Test
    void getByNameAndLanguage_shouldThrowResourceNotFoundWhenTemplateDoesNotExist() {

        when(queryService.getByNameLanguageAndWaba(1L, "nonexistent", "en", "waba-123"))
                .thenThrow(new ResourceNotFoundException(
                        "Template not found: name='nonexistent' language='en'"));

        assertThatThrownBy(() -> getTemplateUseCase
                .getByNameAndLanguage(1L, "nonexistent", "en", "waba-123"))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("nonexistent");
    }

    // ── list ──────────────────────────────────────────────────────────────────

    @Test
    void list_shouldReturnPagedTemplates() {

        // Arrange
        WhatsappTemplate fakeTemplate = new WhatsappTemplate();
        fakeTemplate.setId(1L);
        fakeTemplate.setName("promo_template");

        TemplateResponseDto fakeDto = TemplateResponseDto.builder()
                .id(1L)
                .name("promo_template")
                .build();

        Page<WhatsappTemplate> fakePage = new PageImpl<>(
                List.of(fakeTemplate), PageRequest.of(0, 10), 1L);

        Page<TemplateResponseDto> fakeDtoPage = new PageImpl<>(
                List.of(fakeDto), PageRequest.of(0, 10), 1L);

        when(queryService.listByProject(eq(1L), any(), any(), any(),
                eq(0), eq(10), eq("createdAt"), eq("desc")))
                .thenReturn(fakePage);

        when(responseMapper.toPage(fakePage)).thenReturn(fakeDtoPage);

        // Act
        Page<TemplateResponseDto> result = getTemplateUseCase.list(
                1L, null, null, null, 0, 10, "createdAt", "desc");

        // Assert
        assertThat(result).isNotNull();
        assertThat(result.getContent()).hasSize(1);
        assertThat(result.getContent().get(0).getName()).isEqualTo("promo_template");
        assertThat(result.getTotalElements()).isEqualTo(1L);
    }

    @Test
    void list_shouldReturnEmptyPageWhenNoTemplatesExist() {

        // Arrange
        Page<WhatsappTemplate> emptyPage = new PageImpl<>(
                List.of(), PageRequest.of(0, 10), 0L);

        Page<TemplateResponseDto> emptyDtoPage = new PageImpl<>(
                List.of(), PageRequest.of(0, 10), 0L);

        when(queryService.listByProject(eq(1L), any(), any(), any(),
                eq(0), eq(10), eq("createdAt"), eq("desc")))
                .thenReturn(emptyPage);

        when(responseMapper.toPage(emptyPage)).thenReturn(emptyDtoPage);

        // Act
        Page<TemplateResponseDto> result = getTemplateUseCase.list(
                1L, null, null, null, 0, 10, "createdAt", "desc");

        // Assert
        assertThat(result.getContent()).isEmpty();
        assertThat(result.getTotalElements()).isEqualTo(0L);
    }
}