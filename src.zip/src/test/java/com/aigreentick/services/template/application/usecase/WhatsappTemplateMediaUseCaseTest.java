package com.aigreentick.services.template.application.usecase;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.IOException;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;

import com.aigreentick.services.template.api.dto.response.client.AccessTokenIdentifier;
import com.aigreentick.services.template.api.dto.response.client.FacebookApiResponse;
import com.aigreentick.services.template.api.dto.response.media.ResumableMediaUploadResponseDto;
import com.aigreentick.services.template.api.dto.response.media.UploadMediaResponse;
import com.aigreentick.services.template.api.dto.response.media.UploadOffsetResponse;
import com.aigreentick.services.template.api.dto.response.media.UploadSessionResponse;
import com.aigreentick.services.template.application.port.FacebookMediaUploadPort;
import com.aigreentick.services.template.application.port.WabaCredentialPort;
import com.aigreentick.services.template.common.exception.ExternalServiceException;

@ExtendWith(MockitoExtension.class)
class WhatsappTemplateMediaUseCaseTest {

    @Mock
    private WabaCredentialPort wClient;

    @Mock
    private FacebookMediaUploadPort fmup;

    @InjectMocks
    private WhatsappTemplateMediaUseCase whatsappTemplateMediaUseCase;

    // ── helper ────────────────────────────────────────────────────────────────

    private MockMultipartFile buildMockFile() {
        return new MockMultipartFile(
                "file",
                "product_image.jpg",
                "image/jpeg",
                "fake-image-bytes".getBytes());
    }

    // ── happy path ────────────────────────────────────────────────────────────

    @Test
    void uploadMedia_shouldUploadSuccessfullyAndReturnResponseDto() throws IOException {

        // Arrange
        MockMultipartFile mockFile = buildMockFile();

        UploadSessionResponse sessionResponse = new UploadSessionResponse();
        sessionResponse.setUploadSessionId("session-abc");

        UploadMediaResponse mediaResponse = new UploadMediaResponse();
        mediaResponse.setFacebookImageUrl("https://fb.com/handle-xyz");

        when(wClient.getWhatsappAccountWabaAccessToken("waba-123"))
                .thenReturn(new AccessTokenIdentifier("access-token-xyz"));
        when(fmup.initiateUploadSession(
                eq("product_image.jpg"), anyLong(), eq("image/jpeg"),
                eq("waba-123"), eq("access-token-xyz")))
                .thenReturn(FacebookApiResponse.success(sessionResponse, 200));
        when(fmup.uploadResumableMediaToFacebook(
                eq("session-abc"), any(File.class), eq("access-token-xyz"), eq("0")))
                .thenReturn(FacebookApiResponse.success(mediaResponse, 200));

        // Act
        ResumableMediaUploadResponseDto result = whatsappTemplateMediaUseCase
                .uploadMedia(mockFile, 1L, 2L, "waba-123");

        // Assert
        assertThat(result).isNotNull();
        assertThat(result.getFileName()).isEqualTo("product_image.jpg");
        assertThat(result.getMimeType()).isEqualTo("image/jpeg");
        assertThat(result.getMediaUrl()).isEqualTo("https://fb.com/handle-xyz");
        assertThat(result.getSessionId()).isEqualTo("session-abc");
    }

    // ── session initiation failure ────────────────────────────────────────────

    @Test
    void uploadMedia_shouldThrowExternalServiceExceptionWhenSessionInitiationFails()
            throws IOException {

        // Arrange
        MockMultipartFile mockFile = buildMockFile();

        when(wClient.getWhatsappAccountWabaAccessToken("waba-123"))
                .thenReturn(new AccessTokenIdentifier("access-token-xyz"));
        when(fmup.initiateUploadSession(
                anyString(), anyLong(), anyString(), anyString(), anyString()))
                .thenReturn(FacebookApiResponse.error("Session creation failed", 500));

        // Act + Assert
        assertThatThrownBy(() -> whatsappTemplateMediaUseCase
                .uploadMedia(mockFile, 1L, 2L, "waba-123"))
                .isInstanceOf(ExternalServiceException.class);

        // Upload should never be called if session fails
        verify(fmup, never()).uploadResumableMediaToFacebook(
                anyString(), any(), anyString(), anyString());
    }

    // ── retry on upload failure ───────────────────────────────────────────────

    @Test
    void uploadMedia_shouldRetryWithOffsetWhenInitialUploadFails() throws IOException {

        // Arrange
        // This tests the retry logic in tryUploadToFacebook()
        // First upload throws → getUploadOffset called → retry with new offset
        MockMultipartFile mockFile = buildMockFile();

        UploadSessionResponse sessionResponse = new UploadSessionResponse();
        sessionResponse.setUploadSessionId("session-abc");

        UploadMediaResponse mediaResponse = new UploadMediaResponse();
        mediaResponse.setFacebookImageUrl("https://fb.com/handle-xyz");

        UploadOffsetResponse offsetResponse = new UploadOffsetResponse();
        offsetResponse.setFileOffset("1024");

        when(wClient.getWhatsappAccountWabaAccessToken("waba-123"))
                .thenReturn(new AccessTokenIdentifier("access-token-xyz"));
        when(fmup.initiateUploadSession(
                anyString(), anyLong(), anyString(), anyString(), anyString()))
                .thenReturn(FacebookApiResponse.success(sessionResponse, 200));

        // First upload attempt throws IOException → triggers retry
        when(fmup.uploadResumableMediaToFacebook(
                eq("session-abc"), any(File.class), eq("access-token-xyz"), eq("0")))
                .thenThrow(new IOException("Connection reset"));

        // getUploadOffset called during retry
        when(fmup.getUploadOffset("session-abc", "access-token-xyz"))
                .thenReturn(offsetResponse);

        // Retry with new offset succeeds
        when(fmup.uploadResumableMediaToFacebook(
                eq("session-abc"), any(File.class), eq("access-token-xyz"), eq("1024")))
                .thenReturn(FacebookApiResponse.success(mediaResponse, 200));

        // Act
        ResumableMediaUploadResponseDto result = whatsappTemplateMediaUseCase
                .uploadMedia(mockFile, 1L, 2L, "waba-123");

        // Assert — retry succeeded with offset
        assertThat(result.getMediaUrl()).isEqualTo("https://fb.com/handle-xyz");
        assertThat(result.getSessionId()).isEqualTo("session-abc");

        // Verify getUploadOffset was called during retry
        verify(fmup).getUploadOffset("session-abc", "access-token-xyz");

        // Verify upload was called twice — first with "0", then with "1024"
        verify(fmup).uploadResumableMediaToFacebook(
                eq("session-abc"), any(File.class), eq("access-token-xyz"), eq("0"));
        verify(fmup).uploadResumableMediaToFacebook(
                eq("session-abc"), any(File.class), eq("access-token-xyz"), eq("1024"));
    }
}