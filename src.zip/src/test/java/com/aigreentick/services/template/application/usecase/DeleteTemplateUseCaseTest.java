package com.aigreentick.services.template.application.usecase;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.anyString;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.aigreentick.services.template.api.dto.response.client.AccessTokenIdentifier;
import com.aigreentick.services.template.api.dto.response.client.FacebookApiResponse;
import com.aigreentick.services.template.application.port.FacebookTemplatePort;
import com.aigreentick.services.template.application.port.WabaCredentialPort;
import com.aigreentick.services.template.common.exception.ResourceNotFoundException;
import com.aigreentick.services.template.domain.enums.TemplateStatus;
import com.aigreentick.services.template.domain.model.WhatsappTemplate;
import com.aigreentick.services.template.domain.service.TemplateCommandService;
import com.aigreentick.services.template.domain.service.TemplateQueryService;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;


@ExtendWith(MockitoExtension.class)
class DeleteTemplateUseCaseTest {

    @Mock
    private TemplateQueryService queryService;

    @Mock
    private TemplateCommandService commandService;

    @Mock
    private WabaCredentialPort accountClient;

    @Mock
    private FacebookTemplatePort ftp;

    @InjectMocks
    private DeleteTemplateUseCase deleteTemplateUseCase;

    // ── deleteById ────────────────────────────────────────────────────────────

    @Test
    void deleteById_shouldSoftDeleteLocallyWhenDeleteFromMetaIsFalse() {

        // Arrange
        when(commandService.softDeleteById(1L, 1L)).thenReturn(1);

        // Act
        int result = deleteTemplateUseCase.deleteById(1L, 1L, false);

        // Assert
        assertThat(result).isEqualTo(1);

        // queryService should never be called when deleteFromMeta=false
        verify(queryService, never()).getByIdAndProject(anyLong(), anyLong());
        // Facebook port should never be called
        verify(ftp, never()).deleteTemplate(anyString(), anyString(), anyString());
        verify(commandService).softDeleteById(1L, 1L);
    }

    @Test
    void deleteById_shouldDeleteFromMetaAndLocallyWhenDeleteFromMetaIsTrue() {

        // Arrange
        WhatsappTemplate fakeTemplate = new WhatsappTemplate();
        fakeTemplate.setId(1L);
        fakeTemplate.setName("order_confirmation");
        fakeTemplate.setMetaTemplateId("meta-123");
        fakeTemplate.setWabaId("waba-123");
        fakeTemplate.setStatus(TemplateStatus.APPROVED);

        when(queryService.getByIdAndProject(1L, 1L)).thenReturn(fakeTemplate);
        when(accountClient.getWhatsappAccountWabaAccessToken("waba-123"))
                .thenReturn(new AccessTokenIdentifier("access-token-xyz"));
        when(ftp.deleteTemplate("order_confirmation", "waba-123", "access-token-xyz"))
                .thenReturn(FacebookApiResponse.success(
                        JsonNodeFactory.instance.objectNode(), 200));
        when(commandService.softDeleteById(1L, 1L)).thenReturn(1);

        // Act
        int result = deleteTemplateUseCase.deleteById(1L, 1L, true);

        // Assert
        assertThat(result).isEqualTo(1);

        // verify full flow executed in order
        verify(queryService).getByIdAndProject(1L, 1L);
        verify(accountClient).getWhatsappAccountWabaAccessToken("waba-123");
        verify(ftp).deleteTemplate("order_confirmation", "waba-123", "access-token-xyz");
        verify(commandService).softDeleteById(1L, 1L);
    }

    @Test
    void deleteById_shouldStillDeleteLocallyEvenWhenMetaDeletionFails() {

        // Arrange
        // Meta deletion failure should NOT block local soft-delete
        // This tests the "failures are logged but don't block local deletion" behavior
        WhatsappTemplate fakeTemplate = new WhatsappTemplate();
        fakeTemplate.setId(1L);
        fakeTemplate.setName("order_confirmation");
        fakeTemplate.setMetaTemplateId("meta-123");
        fakeTemplate.setWabaId("waba-123");

        when(queryService.getByIdAndProject(1L, 1L)).thenReturn(fakeTemplate);
        when(accountClient.getWhatsappAccountWabaAccessToken("waba-123"))
                .thenReturn(new AccessTokenIdentifier("access-token-xyz"));
        when(ftp.deleteTemplate("order_confirmation", "waba-123", "access-token-xyz"))
                .thenReturn(FacebookApiResponse.error("Meta error", 500));
        when(commandService.softDeleteById(1L, 1L)).thenReturn(1);

        // Act
        int result = deleteTemplateUseCase.deleteById(1L, 1L, true);

        // Assert — local deletion still happens despite Meta failure
        assertThat(result).isEqualTo(1);
        verify(commandService).softDeleteById(1L, 1L);
    }

    @Test
    void deleteById_shouldSkipMetaDeletionWhenTemplateHasNoMetaTemplateId() {

        // Arrange
        // Template was never submitted to Meta — no metaTemplateId
        WhatsappTemplate fakeTemplate = new WhatsappTemplate();
        fakeTemplate.setId(1L);
        fakeTemplate.setName("draft_template");
        fakeTemplate.setMetaTemplateId(null);   // never submitted

        when(queryService.getByIdAndProject(1L, 1L)).thenReturn(fakeTemplate);
        when(commandService.softDeleteById(1L, 1L)).thenReturn(1);

        // Act
        int result = deleteTemplateUseCase.deleteById(1L, 1L, true);

        // Assert — Facebook port should never be called for unsubmitted templates
        assertThat(result).isEqualTo(1);
        verify(ftp, never()).deleteTemplate(anyString(), anyString(), anyString());
    }

    @Test
    void deleteById_shouldThrowResourceNotFoundWhenTemplateDoesNotExist() {

        // Arrange
        when(commandService.softDeleteById(99L, 1L))
                .thenThrow(new ResourceNotFoundException("Template", "id", 99L));

        // Act + Assert
        assertThatThrownBy(() -> deleteTemplateUseCase.deleteById(99L, 1L, false))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("99");
    }

    // ── deleteAllByProject ────────────────────────────────────────────────────

    @Test
    void deleteAllByProject_shouldReturnDeletedCountWhenTemplatesExist() {

        // Arrange
        when(queryService.countActiveByProject(1L)).thenReturn(5L);
        when(commandService.softDeleteAllByProject(1L)).thenReturn(5);

        // Act
        int result = deleteTemplateUseCase.deleteAllByProject(1L);

        // Assert
        assertThat(result).isEqualTo(5);
        verify(commandService).softDeleteAllByProject(1L);
    }

    @Test
    void deleteAllByProject_shouldReturnZeroWhenNoTemplatesExist() {

        // Arrange
        // countActiveByProject returns 0 — commandService should never be called
        when(queryService.countActiveByProject(1L)).thenReturn(0L);

        // Act
        int result = deleteTemplateUseCase.deleteAllByProject(1L);

        // Assert
        assertThat(result).isEqualTo(0);
        // softDeleteAllByProject should never be called when count is 0
        verify(commandService, never()).softDeleteAllByProject(anyLong());
    }
}